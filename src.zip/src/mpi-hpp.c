/**
 * Cognome: Benazzi
 * Nome: Daniel
 * Matricola: 0000934675 
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h> /* for ceil() */
#include <assert.h>
#include <mpi.h>
#include <memory.h>
#include <stdbool.h>

typedef enum {
    WALL,
    GAS,
    EMPTY
} cell_value_t;

typedef enum {
    ODD_PHASE = -1,
    EVEN_PHASE = 1
} phase_t;

/* type of a cell of the domain */
typedef unsigned char cell_t;

/* Simplifies indexing on an rectangular (N*M) grid */
int IDX_R(int i, int j, int N, int M)
{
    /* wrap-around */
	i = (i+N) % N;
    j = (j+M) % M;
    return i*M + j;
}

/* Simplifies indexing on a N*N grid */
int IDX(int i, int j, int N)
{
	return IDX_R(i, j, N, N);
}

/* Swap the content of cells at indexes a and b, provided that neither is a WALL
   saving them to next; otherwise copy them from cur to next. */
void swap_cells(const cell_t *cur, cell_t *next, int a, int b)
{
    if ((cur[a] != WALL) && (cur[b] != WALL)) {
        next[a] = cur[b];
        next[b] = cur[a];
    } else {
        next[a] = cur[a];
        next[b] = cur[b];
    }
}

/* Compute the `next` grid given the `cur`-rent configuration, starting from
   the specified offset row (zero based), on an N*M grid */
void step( const cell_t *cur, cell_t *next, int N, int M, phase_t phase, int row_offset )
{
    int i, j;

    assert(cur != NULL);
    assert(next != NULL);
	assert(row_offset >= 0);

    /* Loop over all coordinates (i,j) s.t. both i and j are even */
    for (i=row_offset; i<N; i+=2) {
        for (j=0; j<M; j+=2) {
            /**
             * If phase==EVEN_PHASE:
             * ab
             * cd
             *
             * If phase==ODD_PHASE:
             * dc
             * ba
             */
            const int a = IDX_R(i      , j      , N, M);
            const int b = IDX_R(i      , j+phase, N, M);
            const int c = IDX_R(i+phase, j      , N, M);
            const int d = IDX_R(i+phase, j+phase, N, M);
            if ((((cur[a] == EMPTY) != (cur[b] == EMPTY)) &&
                 ((cur[c] == EMPTY) != (cur[d] == EMPTY))) ||
                (cur[a] == WALL) || (cur[b] == WALL) ||
                (cur[c] == WALL) || (cur[d] == WALL)) {
                swap_cells(cur, next, a, b);
                swap_cells(cur, next, c, d);
            } else {
                swap_cells(cur, next, a, d);
                swap_cells(cur, next, b, c);
            }
        }
    }
}

/* Compute the `next` grid given the `cur`-rent configuration. */
void global_step( const cell_t *cur, cell_t *next, int N, phase_t phase )
{
    step(cur,next,N,N,phase,0);
}

/**
 ** The functions below are used to draw onto the grid; since they are
 ** called during initialization only, they do not need to be
 ** parallelized.
 **/
void box( cell_t *grid, int N, float x1, float y1, float x2, float y2, cell_value_t t )
{
    const int ix1 = ceil(fminf(x1, x2) * N);
    const int ix2 = ceil(fmaxf(x1, x2) * N);
    const int iy1 = ceil(fminf(y1, y1) * N);
    const int iy2 = ceil(fmaxf(y1, y2) * N);
    int i, j;
    for (i = iy1; i <= iy2; i++) {
        for (j = ix1; j <= ix2; j++) {
            const int ij = IDX(N-1-i, j, N);
            grid[ij] = t;
        }
    }
}

void circle( cell_t *grid, int N, float x, float y, float r, cell_value_t t )
{
    const int ix = ceil(x * N);
    const int iy = ceil(y * N);
    const int ir = ceil(r * N);
    int dx, dy;
    for (dy = -ir; dy <= ir; dy++) {
        for (dx = -ir; dx <= ir; dx++) {
            if (dx*dx + dy*dy <= ir*ir) {
                const int ij = IDX(N-1-iy-dy, ix+dx, N);
                grid[ij] = t;
            }
        }
    }
}

void random_fill( cell_t *grid, int N, float x1, float y1, float x2, float y2, float p )
{
    const int ix1 = ceil(fminf(x1, x2) * N);
    const int ix2 = ceil(fmaxf(x1, x2) * N);
    const int iy1 = ceil(fminf(y1, y1) * N);
    const int iy2 = ceil(fmaxf(y1, y2) * N);
    int i, j;
    for (i = iy1; i <= iy2; i++) {
        for (j = ix1; j <= ix2; j++) {
            const int ij = IDX(N-1-i, j, N);
            if (grid[ij] == EMPTY && ((float)rand())/RAND_MAX < p)
                grid[ij] = GAS;
        }
    }
}

void read_problem( FILE *filein, cell_t *grid, int N )
{
    int i,j;
    int nread;
    char op;

    for (i=0; i<N; i++) {
        for (j=0; j<N; j++) {
            const int ij = IDX(i,j,N);
            grid[ij] = EMPTY;
        }
    }

    while ((nread = fscanf(filein, " %c", &op)) == 1) {
        int t;
        float x1, y1, x2, y2, r, p;
        int retval;

        switch (op) {
        case 'c' : /* circle */
            retval = fscanf(filein, "%f %f %f %d", &x1, &y1, &r, &t);
            assert(retval == 4);
            circle(grid, N, x1, y1, r, t);
            break;
        case 'b': /* box */
            retval = fscanf(filein, "%f %f %f %f %d", &x1, &y1, &x2, &y2, &t);
            assert(retval == 5);
            box(grid, N, x1, y1, x2, y2, t);
            break;
        case 'r': /* random_fill */
            retval = fscanf(filein, "%f %f %f %f %f", &x1, &y1, &x2, &y2, &p);
            assert(retval == 5);
            random_fill(grid, N, x1, y1, x2, y2, p);
            break;
        default:
            fprintf(stderr, "FATAL: Unrecognized command `%c`\n", op);
            exit(EXIT_FAILURE);
        }
    }
}


/* Write an image of `grid` to a file in PGM (Portable Graymap)
   format. `frameno` is the time step number, used for labeling the
   output file. */
void write_image( const cell_t *grid, int N, int frameno )
{
    FILE *f;
    char fname[128];

    snprintf(fname, sizeof(fname), "mpi-hpp%05d.pgm", frameno);
    if ((f = fopen(fname, "w")) == NULL) {
        printf("Cannot open \"%s\" for writing\n", fname);
        abort();
    }
    fprintf(f, "P5\n");
    fprintf(f, "# produced by hpp\n");
    fprintf(f, "%d %d\n", N, N);
    fprintf(f, "%d\n", EMPTY); /* highest shade of grey (0=black) */
    fwrite(grid, 1, N*N, f);
    fclose(f);
}

int main( int argc, char* argv[] )
{
    int t, N, nsteps, my_rank, comm_sz, local_rows;
	int *displs = NULL, *sendcnts = NULL;
    cell_t *grid = NULL, *local_cur_ex, *local_next_ex, *local_cur,
		*local_next, *send_buf;
    FILE *filein;
	
	/* init MPI */
	MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
	
	srand(1234); /* Initialize PRNG deterministically */

    /* if main process check parameters */
	if (my_rank == 0) {
		if ( (argc < 2) || (argc > 4) ) {
			fprintf(stderr, "Usage: %s [N [S]] input\n", argv[0]);
			MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
		}
        printf("running with %d processes\n", comm_sz);
    }

    /* Wait and initialize inputs. */
    MPI_Barrier(MPI_COMM_WORLD);
    if (argc > 2) {
        N = atoi(argv[1]);
    } else {
        N = 512;
    }
    if (argc > 3) {
        nsteps = atoi(argv[2]);
    } else {
        nsteps = 32;
    }

    /* If main process check grid size and read input. */
    if (my_rank == 0 ){
        if (N % 2 != 0) {
            fprintf(stderr, "FATAL: the domain size N must be even\n");
            MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
        }

        if ((filein = fopen(argv[argc-1], "r")) == NULL) {
            fprintf(stderr, "FATAL: can not open \"%s\" for reading\n", argv[argc-1]);
            MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
        }

        const size_t GRID_SIZE = N*N*sizeof(cell_t);
        grid = (cell_t*)malloc(GRID_SIZE);
        assert(grid != NULL);

        read_problem(filein, grid, N);
        fclose(filein);
    }

	/* Initialize indexes*/
	/* Assign an even number of rows to each process */
    local_rows = ((N/2)/comm_sz)*2;
    const int local_columns = N;
    /* Check if some rows are not assigned to a process */
    const int leftover_rows = N % local_rows;
	/* assign leftover rows to last process */
	if (my_rank == comm_sz-1) {
		local_rows += leftover_rows;
	}
    const int local_rows_ex = local_rows + 1; /* local domain + phantom row */

    /* Initialize local domains */
    const size_t LOCAL_GRID_SIZE_EX = local_rows_ex*local_columns*sizeof(cell_t);
    local_cur_ex = (cell_t*)malloc(LOCAL_GRID_SIZE_EX);
    assert(local_cur_ex != NULL);
    local_cur = &local_cur_ex[local_columns];
	
    local_next_ex = (cell_t*)malloc(LOCAL_GRID_SIZE_EX);
    assert(local_next_ex != NULL);
    local_next = &local_next_ex[local_columns];
    /* Create send buffer for local grid rows. */
    /* This is not necessary but it simplifies problems with send calls */
	send_buf = (cell_t*)malloc(local_columns*sizeof(cell_t));
    assert(send_buf != NULL);

	/* Define previous/next process' rank */
    const int NEXT = (my_rank + 1) % comm_sz;
    const int PREV = (my_rank + comm_sz -1) % comm_sz;
    if (my_rank == 0) {
		/* Calculate sendcnts and and displs for Scatter/Gatherv */
		sendcnts = (int*)malloc(comm_sz*sizeof(*sendcnts));
		assert(sendcnts != NULL);
		displs = (int*)malloc(comm_sz*sizeof(*displs));
		assert(displs != NULL);
		/* Calculate values for scatterv */
		for (t=0; t<comm_sz; t++) {
			sendcnts[t] = local_rows*local_columns;
			displs[t] = sendcnts[t]*t;
		}
		sendcnts[comm_sz-1] += leftover_rows*local_columns; 

#ifdef DBG				
		const size_t LOCAL_GRID_SIZE = local_rows*local_columns*sizeof(cell_t);
        printf("process %d dbg info:\n	local_rows: %d local_columns: %d leftover_rows: %d\n",
				my_rank, local_rows, local_columns, leftover_rows);
        printf("	GRID_SIZE:%ld LOCAL_GRID_SIZE: %ld LOCAL_GRID_SIZE_EX: %ld\n",
				N*N*sizeof(cell_t), LOCAL_GRID_SIZE, LOCAL_GRID_SIZE_EX);
		printf("	PREV:%d NEXT:%d\n", PREV, NEXT);
		printf("	pointers: grid:%p local_cur_ex:%p local_cur:%p \n\
	local_next_ex:%p local_next:%p send_buf:%p\n", 
				(void*)grid, (void*)local_cur_ex, (void*)local_cur, 
				(void*)local_next_ex, (void*)local_next, (void*)send_buf);
		for (t=0; t<comm_sz; t++) {
			printf("for process %d: sendcount:%d | displs:%d\n", t, sendcnts[t], displs[t]);
		}
#endif
    }
	
	/* Create cell datatype */
    MPI_Datatype MPI_Cell;
    MPI_Type_contiguous(1, /* count */
                        MPI_UNSIGNED_CHAR, /* oldtype*/
                        &MPI_Cell /* newtype */);
    MPI_Type_commit(&MPI_Cell);

#ifdef PRINT_TIME
	double t0 = 0;
	if (my_rank == 0) {
		t0 = MPI_Wtime();
	}
#endif

	/* Send partitioned domain */
    MPI_Scatterv(grid, /* sendbuf */
				sendcnts, /* sendcount */
				displs, /* displacements */
				MPI_Cell, /* sendtype */
				local_cur, /* recvbuf */
				local_rows*local_columns, /* recvcount */
				MPI_Cell, /* recvtype */
				0, /* root */
				MPI_COMM_WORLD /* comm */);

    for (t=0; t<nsteps; t++) {
#ifdef DUMP_ALL
	MPI_Gatherv(local_cur, /* sendbuf */
			   local_rows*local_columns, /* sendcount */
			   MPI_Cell, /* sendtype */
			   grid, /* recvbuf */
			   sendcnts, /* recvcounts */
			   displs, /* displacements */
			   MPI_Cell, /* recvtype */
			   0, /* root */
			   MPI_COMM_WORLD /* comm */);
	if ( my_rank == 0) {
				   write_image(grid, N, t);
	}
#endif
		
        step(local_cur, local_next, local_rows, local_columns, EVEN_PHASE, 0);

        /* Copy last row */
        memcpy(send_buf,
            &local_next[IDX_R(local_rows-1, 0, local_rows, local_columns)],
            local_columns);
        /* Send bottom row to NEXT (and receive top halo from PREV) */
        MPI_Sendrecv(send_buf, /* sendbuf */
                    local_columns, /* sendcount */
                    MPI_Cell, /* sendtype */
                    NEXT, /* dest */
                    0, /* sendtag */
                    local_next_ex, /* recvbuf */
                    local_columns, /* recvcount */
                    MPI_Cell, /* recvtype */
                    PREV, /* source */
                    0, /* recvtag */
                    MPI_COMM_WORLD,/* comm */
                    MPI_STATUS_IGNORE/* status */);

        step(local_next_ex, local_cur_ex, local_rows_ex, local_columns, ODD_PHASE, 1);
				   
		/* Copy top halo row */
		memcpy(send_buf, local_cur_ex, local_columns);
		/* Send top halo row to PREV (and receive bottom row from NEXT) */
		MPI_Sendrecv(send_buf, /* sendbuf */
                    local_columns, /* sendcount */
                    MPI_Cell, /* sendtype */
                    PREV, /* dest */
                    0, /* sendtag */
                    &local_cur[IDX_R(local_rows-1, 0,
							local_rows, local_columns)], /* recvbuf */
                    local_columns, /* recvcount */
                    MPI_Cell, /* recvtype */
                    NEXT, /* source */
                    0, /* recvtag */
                    MPI_COMM_WORLD,/* comm */
                    MPI_STATUS_IGNORE/* status */);

	

    }
	/* Receive domain data */
	MPI_Gatherv(local_cur, /* sendbuf */
			   local_rows*local_columns, /* sendcount */
			   MPI_Cell, /* sendtype */
			   grid, /* recvbuf */
			   sendcnts, /* recvcounts */
			   displs, /* displacements */
			   MPI_Cell, /* recvtype */
			   0, /* root */
			   MPI_COMM_WORLD /* comm */);
	
	MPI_Type_free(&MPI_Cell);

#ifdef PRINT_TIME
	if (my_rank == 0) {
		printf("working time: %.3f seconds\n", (MPI_Wtime()-t0));
	}
#endif

#ifdef DUMP_ALL
    /* reverse computation only if main process */
    if (my_rank == 0){
		const size_t GRID_SIZE = N*N*sizeof(cell_t);
        cell_t *next = (cell_t*)malloc(GRID_SIZE);
        assert(next != NULL);
        /* Reverse all particles and go back to the initial state */
        for (; t<2*nsteps; t++) {
            write_image(grid, N, t);
            global_step(grid, next, N, ODD_PHASE);
            global_step(next, grid, N, EVEN_PHASE);
        }
        free(next);
    }
#endif

    // /* if main process output image */
    if (my_rank == 0)
    {
        write_image(grid, N, t);
        free(grid);
		free(displs);
		free(sendcnts);
    }
    free(local_cur_ex);
    free(local_next_ex);
	free(send_buf);
    MPI_Finalize();
#ifdef DBG
    printf("process %d: exiting\n", my_rank);
#endif
    return EXIT_SUCCESS;
}
