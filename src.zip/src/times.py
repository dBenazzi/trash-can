#!/bin/python
import shutil as sh
import os
from shlex import split as shs
import subprocess
import sys


def cmpl(command, name):
    """ Run specified command.
        Args:
            command: a list of strings containing the command followed by its arguments
            name: command name
    """
    print("compiling ", name, " program:")
    try:
        subprocess.run(command, check=True)
    except subprocess.SubprocessError() as err:
        print("ERROR: could not compile ", name, " file. errorcode: ", err)
    print("done\n")


def get_execution_time(command, environment=None) -> float:
    """ Run specified executable, searches for execution time in its STDOUT, then returns it
        Args:
            command: a list of strings containing the command followed by its arguments

        Returns:
            float: time in seconds
    """
    time = None
    try:
        clp = subprocess.run(command, check=True, capture_output=True,
                             text=True, env=environment)
        for line in clp.stdout.splitlines():
            if "working time" in line:
                time = line.split()[2]
    except subprocess.SubprocessError() as err:
        print("error running process", err)
        return 0.0
    return time


def get_average_time(runs, command, environment=None) -> float:
    """ Run specified command for runs times and find average execution
        Args:
            command: a list of strings containing the command followed by its arguments

        Returns:
            float: time in seconds
    """
    times = [float(get_execution_time(command, environment=environment))
             for i in range(runs)]
    print(times)
    return sum(times)/len(times)


OMP_FLAGS = shs(
    "-std=c99 -O3 -fopenmp -DPRINT_TIME omp-hpp.c -o omp-hpp -lm")
MPI_FLAGS = shs(
    "-std=c99 -O3 -DPRINT_TIME mpi-hpp.c -o mpi-hpp -lm")
GRID_SIZE = "1024"
PASSES = "256"
PROC_NUM = os.cpu_count()
OMP_TIME = []
OMP_SPUP = []
OMP_SSCE = []
MPI_TIME = []
MPI_SPUP = []
MPI_SSCE = []
RUNS = 10


if __name__ == "__main__":
    ompc = sh.which("gcc")
    mpic = sh.which("mpicc")
    mpir = sh.which("mpirun")
    if (ompc is None or mpic is None or mpir is None
        or not os.path.isfile("./omp-hpp.c")
            or not os.path.isfile("./mpi-hpp.c") or not os.path.isfile("./walls.in")):
        print("ERROR searching for files and/or compilers")
        sys.exit(-1)

    # compile programs
    cmpl([ompc] + OMP_FLAGS, "OpenMP")
    cmpl([mpic] + MPI_FLAGS, "MPI")

    # run programs (and catch resulting time)
    ompr = ["./omp-hpp", GRID_SIZE, PASSES, "walls.in"]
    # run omp with incresing number of processors
    print("running OpenMP program:")
    for p in range(1, PROC_NUM+1):
        print(RUNS, "runs with", p, "thread(s):")
        env = {"OMP_NUM_THREADS": str(p)}
        OMP_TIME.append(get_average_time(RUNS, ompr, environment=env))
    print("done\n")

    # run mpi with incresing number of processors
    print("running MPI program:")
    for p in range(1, PROC_NUM+1):
        print(RUNS, "runs with", p, "process(es):")
        lmpir = [mpir, "-n", str(p), "./mpi-hpp",
                 GRID_SIZE, PASSES, "walls.in"]
        MPI_TIME.append(get_average_time(RUNS, lmpir))
    print("done.\n")

    print(OMP_TIME, MPI_TIME)

    # output results (speedup and strong scaling efficency)
    # omp speedup
    print("OpenMP speedup and strong scaling efficiency:")
    for i in range(1, len(OMP_TIME)):
        speedup = OMP_TIME[0]/OMP_TIME[i]
        sse = speedup/(i+1)
        print(f"with {i+1} threads: speedup: {speedup} | strong s.e.: {sse}")
        OMP_SPUP.append(speedup)
        OMP_SSCE.append(sse)

    # mpi speedup
    print("MPI speedup and strong scaling efficiency:")
    for i in range(1, len(MPI_TIME)):
        speedup = MPI_TIME[0]/MPI_TIME[i]
        sse = speedup/(i+1)
        print(f"with {i+1} processes: speedup: {speedup} | strong s.e.: {sse}")
        MPI_SPUP.append(speedup)
        MPI_SSCE.append(sse)

    print(OMP_TIME, OMP_SPUP, OMP_SSCE)
    print(MPI_TIME, MPI_SPUP, MPI_SSCE)
    # matplotlib
    # execution times

    # speedup

    # strong scaling efficiency
