# -*- coding: utf-8 -*-
"""
Created on Thu Sep 22 15:07:48 2022

@author: benazzi
"""
from matplotlib import pyplot as plt


def plotted(title, vecOMP, vecMPI, ylabel, offset):
    plt.figure()
    plt.title(title)
    plt.plot(range(offset, len(vecOMP)+offset), vecOMP, label="OMP")
    plt.plot(range(offset, len(vecMPI)+offset), vecMPI, label="MPI")
    plt.xticks(range(offset, len(vecOMP)+offset))
    plt.legend()
    plt.xlabel("Number of workers")
    plt.ylabel(ylabel)
    plt.savefig(title)


OMP_TIME = [1, 13, 10]
OMP_SPUP = []
OMP_SSCE = []
MPI_TIME = [1, 2, 25]
MPI_SPUP = []
MPI_SSCE = []

if __name__ == "__main__":
    plotted("Execution times",
            OMP_TIME, MPI_TIME, "Time (seconds)", 1)

    plotted("Speedup",
            OMP_SPUP, MPI_SPUP, "Speedup", 2)

    plotted("Strong scaling efficiency",
            OMP_SSCE, MPI_SSCE, "Strong scaling", 2)
